#include "ArrayList.hpp"
#include <vector>
#include <iostream>
#include <cmath>

template<typename T, int dimensions, int numberOfPoints>
class KDTree
{
private:
    struct Node
    {
        ArrayList<T,dimensions> coordinates;
        Node *left;
        Node *right;
    };

    Node *root = nullptr;
    int depth=0;
    int sizeOfTree = 0;

    void sort(ArrayList<ArrayList<T, dimensions>, numberOfPoints> &v, int axis)
    {
        for (int i = 1; i < v.size(); i++)
        {
            ArrayList<T, dimensions> temp = v[i];
            int j = i - 1;
            //[jedna z list][współrzędna]
            // Porównaj elementy względem zadanego indeksu
            while (j >= 0 && v[j][axis] > temp[axis])
            {
                v[j + 1] = v[j];
                j--;
            }

            v[j + 1] = temp;
        }
    }

    Node* creation(ArrayList<ArrayList<T, dimensions>, numberOfPoints>& listOfPoints, int height)
    {
        if (listOfPoints.size() == 0) {
            return nullptr;
        }
        int axis = height % dimensions; //wybieramy oś na danej głębokości
        ArrayList<T, dimensions> median;
        int size = listOfPoints.size();
        sort(listOfPoints, axis); // sortujemy punkty względem wybranej osi
        median = listOfPoints[size / 2]; //wybieramy punkt który jest medianą
        ArrayList<ArrayList<T, dimensions>, numberOfPoints> list1, list2; //tworzymy dwie listy na punkty po lewej i prawej stronie mediany
        for (int i = 0; i < size / 2; i++)
        {
            list1.push_back(listOfPoints[i]);
        }
        for (int i = size / 2 + 1; i < size; i++)
        {
            list2.push_back(listOfPoints[i]);
        }

        Node *temp = new Node();
        for (int i = 0; i < dimensions; i++)
            temp->coordinates.push_back(median[i]); //dodajemy medianę jako punkt/węzeł
        if(height>this->depth) this->depth=height; //kontrola głębokości drzewa
        if (root == nullptr) //kontrola korzenia
        {
            root = temp;
        }
        //rekurencyjnie tworzymy lewe i prawe poddrzewo
        temp->left = creation(list1, height + 1);
        temp->right = creation(list2, height + 1);
        return temp;
    }
    Node* closestPoint(Node* next, Node* prev, ArrayList<T,dimensions> target)
    {
        if(next == nullptr) return prev;
        if(prev == nullptr) return next;

        if(euclideanMetric(next->coordinates, target) > euclideanMetric(prev->coordinates, target)) 
            return prev;
        else 
            return next; 
    }
    Node* search(Node* node, ArrayList<T,dimensions>& point, int height)
    {
        if(node == nullptr) return nullptr;
        
        int axis = height % dimensions; //wybieramy oś na danej głębokości
        Node *next; // gałąź w którą wchodzimy
        Node *other; // druga gałąź
        if(point[axis] < node->coordinates[axis]) //porównujemy punkt z punktem w węźle i idziemy w lewo
        {
            next = node->left;
            other = node->right;
        }
        else // lub w prawo
        {
            next = node->right;
            other = node->left;
        }
        Node* temp = search(next, point, height+1); // wchodzimy do właściwej gałęzi rekurencyjnie
        Node* best = closestPoint(temp, node, point); // jesteśmy na dole drzewa, sprawdzamy czy obecny, czy następny węzeł jest bliższy
//        if(best == nullptr) return nullptr;
        double distance = euclideanMetric(best->coordinates, point); // obliczamy dystans między naiwnym najlepszym punktem a szukanym
        double distanceToBoundary = pow(node->coordinates[axis] - point[axis], 2); // obliczamy dystans między szukanym punktem a granicą wyznaczaną przez węzeł
        if(distance >= distanceToBoundary) // jeśli dystans do granicy jest mniejszy od dystansu do naiwnego najlepszego punktu, 
        //to sprawdzamy drugą gałąź bo za granicą może być bliższy punkt
        {
            temp = search(other, point, height+1); // wchodzimy do drugiej gałęzi 
            best = closestPoint(temp, best, point); // sprawdzamy czy punkt w drugiej gałęzi jest bliższy
        }
        return best;
    }

public:
    KDTree(ArrayList<ArrayList<T, dimensions>, numberOfPoints>& listOfPoints)
    {
        creation(listOfPoints, 0);
    }

    void insert(ArrayList<T,dimensions> point)
    {
        Node *temp =root;
        int level =1;
        while(true)
        {
            level++;
            int axis = (level-2) % dimensions;
            if(point[axis]>=temp->coordinates[axis])
            {
                if(temp->right==nullptr)
                {
                    temp->right=new Node();
                    for(int i=0;i<dimensions;i++)
                    {
                        temp->right->coordinates.push_back(point[i]);
                    }
                    if(level>depth) {depth = level;
                    break;}
                }
                temp=temp->right;
            }
            else
            {
                if(temp->left==nullptr)
                {
                    temp->left=new Node();
                    for(int i=0;i<dimensions;i++)
                    {
                        temp->left->coordinates.push_back(point[i]);
                    }
                    if(level>depth) 
                    {depth = level;
                    break;}
                }
                temp=temp->left;
            }
        }
    }
    ArrayList<T,dimensions> searchNearestNeighbourTo(ArrayList<T,dimensions> point)
    {
        Node* temp = search(root, point, 0);
        if (temp == nullptr) return ArrayList<T,dimensions>();

        return temp->coordinates;
    }
    T euclideanMetric(ArrayList<T,dimensions> point,ArrayList<T,dimensions> target)
    {
        T distance = 0;
        for (int i = 0; i < dimensions; i++)
        {
            T temp = point[i]-target[i];
            distance += temp * temp;
        }
        return distance;
    }
};
